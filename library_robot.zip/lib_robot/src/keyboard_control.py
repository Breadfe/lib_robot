#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
from pynput import keyboard

class KeyboardCmdVelPublisher:
    def __init__(self):
        rospy.init_node('keyboard_cmd_vel_publisher', anonymous=True)
        self.pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
        self.rate = rospy.Rate(10)  # 10 Hz

        self.linear_velocity = 0.3  # m/s
        self.angular_velocity = 1.0  # rad/s
        self.max_linear_velocity = 0.7  # m/s
        self.max_angular_velocity = 5.0  # rad/s
        self.min_linear_velocity = 0.3  # m/s
        self.min_angular_velocity = 1.0  # rad/s

        self.current_twist = Twist()

    def on_press(self, key):
        try:
            if key == keyboard.Key.up:
                self.current_twist.linear.x = self.linear_velocity
                self.current_twist.angular.z = 0.0
            elif key == keyboard.Key.down:
                self.current_twist.linear.x = -self.linear_velocity
                self.current_twist.angular.z = 0.0
            elif key == keyboard.Key.left:
                self.current_twist.linear.x = 0.0
                self.current_twist.angular.z = self.angular_velocity
            elif key == keyboard.Key.right:
                self.current_twist.linear.x = 0.0
                self.current_twist.angular.z = -self.angular_velocity
            elif key.char == 'i':
                self.linear_velocity = min(self.linear_velocity + 0.1, self.max_linear_velocity)
                self.angular_velocity = min(self.angular_velocity + 1, self.max_angular_velocity)
                rospy.loginfo(f"Increasing speed: linear={self.linear_velocity}, angular={self.angular_velocity}")
            elif key.char == 'u':
                self.linear_velocity = max(self.linear_velocity - 0.1, self.min_linear_velocity)
                self.angular_velocity = max(self.angular_velocity - 1, self.min_angular_velocity)
                rospy.loginfo(f"Decreasing speed: linear={self.linear_velocity}, angular={self.angular_velocity}")
        except AttributeError:
            pass

    def on_release(self, key):
        if key in [keyboard.Key.up, keyboard.Key.down, keyboard.Key.left, keyboard.Key.right]:
            self.current_twist.linear.x = 0.0
            self.current_twist.angular.z = 0.0
        if key == keyboard.Key.esc:
            return False

    def run(self):
        with keyboard.Listener(on_press=self.on_press, on_release=self.on_release) as listener:
            while not rospy.is_shutdown():
                self.pub.publish(self.current_twist)
                self.rate.sleep()
            listener.join()

if __name__ == '__main__':
    try:
        node = KeyboardCmdVelPublisher()
        node.run()
    except rospy.ROSInterruptException:
        pass
