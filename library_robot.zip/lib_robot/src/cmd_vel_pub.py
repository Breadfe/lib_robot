#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist

class CmdVelPublisher:
    def __init__(self):
        rospy.init_node('cmd_vel_publisher', anonymous=True)
        self.pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
        self.rate = rospy.Rate(10)  # 10hz

    def get_user_input(self):
        try:
            linear_velocity = float(input("Enter linear velocity (m/s): "))
            angular_velocity = float(input("Enter angular velocity (rad/s): "))
            return linear_velocity, angular_velocity
        except ValueError:
            print("Invalid input. Please enter numeric values.")
            return None, None

    def run(self):
        print("Publishing to /cmd_vel. Press Ctrl+C to exit.")
        while not rospy.is_shutdown():
            linear_velocity, angular_velocity = self.get_user_input()
            if linear_velocity is not None and angular_velocity is not None:
                twist = Twist()
                twist.linear.x = linear_velocity
                twist.angular.z = angular_velocity
                self.pub.publish(twist)
                print("pubed")
            self.rate.sleep()

if __name__ == '__main__':
    try:
        cmd_vel_publisher = CmdVelPublisher()
        cmd_vel_publisher.run()
    except rospy.ROSInterruptException:
        pass