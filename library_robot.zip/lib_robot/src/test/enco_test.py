#!/usr/bin/env python3

import odrive
import time
import math
import rospy
from geometry_msgs.msg import Twist

WHEEL_DIAMETER = 0.129 # wheel diameters
RIGHT_MOTOR = 0
LEFT_MOTOR = 1
FORWARD = 0
BACKWARD = 1
STOP = 2
WHEEL_TO_CENTER = 0.168  # center to wheel center 16.8cm

MAX_LINEAR_VELOCITY = 2
MAX_ANGULAR_VELOCITY = MAX_LINEAR_VELOCITY/WHEEL_TO_CENTER

class MobileRobot:
    def __init__(self):
        self.my_drive = odrive.find_any()
        print('Battery Voltage is : ',str(self.my_drive.vbus_voltage))
        self.motor_right = self.my_drive.axis0.motor
        self.motor_left = self.my_drive.axis1.motor
        
        self.axis_right = self.my_drive.axis0
        self.axis_left = self. my_drive.axis1
        
        self.axis_right.requested_state = 8
        self.axis_left.requested_state = 8


        self.ctrl_right = self.axis_right.controller
        self.ctrl_left = self.axis_left.controller


        # Parameters
        self.ctrl_right.config.pos_gain = 20.0
        self.ctrl_left.config.pos_gain = 20.0

        # # self.ctrl_right.config.vel_gain = 0.848
        # # self.ctrl_left.config.vel_gain = 0.848

        self.ctrl_right.config.vel_gain = 0.9
        self.ctrl_left.config.vel_gain = 0.9

        self.ctrl_right.config.vel_integrator_gain = 0.7 #0.32
        self.ctrl_left.config.vel_integrator_gain = 0.7

        # self.init_node()
        #

    def init_node(self):
        rospy.init_node("move_base", anonymous=True)
        rospy.Subscriber("/cmd_vel", Twist, self.move_base_ros)
        rospy.spin()

    def vel_estimate(self):
        right_rps = self.axis_right.encoder.vel_estimate
        left_rps = self.axis_left.encoder.vel_estimate # turn/sec

        right_pos = self.axis_right.encoder.pos_estimate
        left_pos = self.axis_left.encoder.pos_estimate

        right_vel = self.rps2mps(right_rps)
        left_vel = -self.rps2mps(left_rps)

        print(f'Right vel : {right_vel:.2f} m/s, Left vel : {left_vel:.2f} m/s')
        print(f'Right pos : {right_pos:.2f} m/s, Left pos : {left_pos:.2f} m/s')
    
    def motor_turn(self, axis, direction, velocity = 0): # m/s input
        rps = self.mps2rps(velocity) 
        print(velocity)
        if axis == RIGHT_MOTOR:
            if direction == FORWARD:
                self.ctrl_right.input_vel = rps
            elif direction == BACKWARD:
                self.ctrl_right.input_vel = -rps
            elif direction == STOP:
                self.ctrl_right.input_vel = 0
        elif axis == LEFT_MOTOR:
            if direction == FORWARD:
                self.ctrl_left.input_vel = -rps
            elif direction == BACKWARD:
                self.ctrl_left.input_vel = rps
            elif direction == STOP:
                self.ctrl_left.input_vel = 0

    def mps2rps(self, mps):
        rps = mps/(WHEEL_DIAMETER*math.pi) # wheel 2*radius = 0.129m
        return rps

    def rps2mps(self, rps):
        mps = WHEEL_DIAMETER*math.pi*rps
        return mps
    
    ############# MOVING TEST PART DOWN #############    
    def go_forward(self, velocity):
        self.motor_turn(RIGHT_MOTOR, FORWARD, velocity)
        self.motor_turn(LEFT_MOTOR, FORWARD, velocity) # m/s input
        
    def go_backward(self, velocity):
        self.motor_turn(RIGHT_MOTOR, BACKWARD, velocity)
        self.motor_turn(LEFT_MOTOR, BACKWARD, velocity)
        
    def turn_right(self, angular_velocity):
        self.motor_turn(RIGHT_MOTOR, FORWARD, angular_velocity*WHEEL_TO_CENTER)
        self.motor_turn(LEFT_MOTOR, BACKWARD, angular_velocity*WHEEL_TO_CENTER)
        
    def turn_left(self, angular_velocity):
        self.motor_turn(RIGHT_MOTOR, BACKWARD, angular_velocity*WHEEL_TO_CENTER)
        self.motor_turn(LEFT_MOTOR, FORWARD, angular_velocity*WHEEL_TO_CENTER)
    
    def moving_stop(self):
        self.motor_turn(RIGHT_MOTOR, STOP)
        self.motor_turn(LEFT_MOTOR, STOP)

    def isMaxSpeed(self, velocity, angular_velocity):
        if abs(velocity) > MAX_LINEAR_VELOCITY:
            new_velocity = velocity/abs(velocity) * MAX_LINEAR_VELOCITY
            rospy.logwarn(f"Velocity limit : your vel {velocity} -> {new_velocity}")
        else:
            new_velocity = velocity
        if abs(angular_velocity) > MAX_ANGULAR_VELOCITY:
            new_angular_velocity = angular_velocity/abs(angular_velocity) * MAX_ANGULAR_VELOCITY
            rospy.logwarn(f"Angular Velocity limit : your angular vel {angular_velocity} -> {new_angular_velocity}")
        else:
            new_angular_velocity = angular_velocity

        return new_velocity, new_angular_velocity
    ############# USE THIS METHOD FOR MOVING #############    
    def move_base_(self, velocity, angular_velocity):
        velocity, angular_velocity = self.isMaxSpeed(velocity, angular_velocity)
        left_motor_vel = velocity - WHEEL_TO_CENTER*angular_velocity
        right_motor_vel = velocity + WHEEL_TO_CENTER*angular_velocity
        self.motor_turn(RIGHT_MOTOR, FORWARD, right_motor_vel)
        self.motor_turn(LEFT_MOTOR, FORWARD, left_motor_vel)
        while(1):
          self.vel_estimate()
          time.sleep(0.5)
        
    
    def move_base_ros(self, cmd_vel):
        x = cmd_vel.linear.x
        z = cmd_vel.angular.z

        self.move_base_(x, z)

if __name__ == '__main__':
    robot = None

    try:
        robot = MobileRobot()

        while(True):
            robot.vel_estimate()
        # vel = 1   # m/s
        # angular_velocity = 3 # rad/s
        
        # robot.move_base(vel, angular_velocity)
        # for _ in range(10):
        #     robot.vel_estimate()
        #     time.sleep(0.2)
        
        # robot.moving_stop()


        print('done')

    except KeyboardInterrupt:
        if robot is not None:
            robot.moving_stop()
        else:
            robot = MobileRobot()
            robot.moving_stop()
        exit()
