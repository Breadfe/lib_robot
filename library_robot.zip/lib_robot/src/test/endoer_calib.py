import odrive
from odrive.enums import *
import time

# ODrive
print("Finding an ODrive...")
odrv0 = odrive.find_any()

# ȭ
print("Starting encoder offset calibration...")
odrv0.axis0.requested_state = AXIS_STATE_ENCODER_OFFSET_CALIBRATION

# 
while odrv0.axis0.current_state != AXIS_STATE_IDLE:
    time.sleep(0.1)

# 
if odrv0.axis0.encoder.is_ready:
    print("Encoder calibration successful!")
else:
    print("Encoder calibration failed!")

#
print("Setting to closed loop control...")
odrv0.axis0.requested_state = AXIS_STATE_CLOSED_LOOP_CONTROL

#
print("Axis0 state: ", odrv0.axis0.current_state)
print("Axis0 error: ", odrv0.axis0.error)
print("Encoder error: ", odrv0.axis0.encoder.error)

# 
print("Encoder position: ", odrv0.axis0.encoder.pos_estimate)

print("Starting encoder offset calibration...")

odrv0.axis1.requested_state = AXIS_STATE_ENCODER_OFFSET_CALIBRATION

# 
while odrv0.axis1.current_state != AXIS_STATE_IDLE:
    time.sleep(0.1)

# 
if odrv0.axis1.encoder.is_ready:
    print("Encoder calibration successful!")
else:
    print("Encoder calibration failed!")

#
print("Setting to closed loop control...")
odrv0.axis1.requested_state = AXIS_STATE_CLOSED_LOOP_CONTROL

#
print("Axis1 state: ", odrv0.axis1.current_state)
print("Axis1 error: ", odrv0.axis1.error)
print("Encoder error: ", odrv0.axis1.encoder.error)

# 
print("Encoder position: ", odrv0.axis1.encoder.pos_estimate)
