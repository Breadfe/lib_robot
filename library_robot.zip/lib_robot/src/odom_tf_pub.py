#!/usr/bin/env python3

import rospy
from std_msgs.msg import Float64
from nav_msgs.msg import Odometry
from geometry_msgs.msg import TransformStamped
from tf import TransformBroadcaster
import tf
import math

class OdometryPublisher:
    def __init__(self):
        rospy.init_node('odometry_publisher', anonymous=True)

        # Subscribers for encoder values
        rospy.Subscriber('/encoder_left', Float64, self.encoder_left_callback)
        rospy.Subscriber('/encoder_right', Float64, self.encoder_right_callback)

        # Publisher for odometry
        self.odom_pub = rospy.Publisher('/odom', Odometry, queue_size=50)

        # TF broadcaster
        self.odom_broadcaster = TransformBroadcaster()

        # Initial values
        self.encoder_left = 0
        self.encoder_right = 0
        self.prev_encoder_left = 0
        self.prev_encoder_right = 0
        self.x = 0.0
        self.y = 0.0
        self.th = 0.0
        self.prev_time = rospy.Time.now()

        self.rate = rospy.Rate(60)

        # Parameters for robot
        self.wheel_base = 0.168*2  # Distance between wheels
        self.wheel_radius = 0.129/2  # Wheel radius
        self.ticks_per_revolution = 1  # Encoder resolution

    def encoder_left_callback(self, msg):
        self.encoder_left = msg.data

    def encoder_right_callback(self, msg):
        self.encoder_right = msg.data

    def compute_odometry(self):
        current_time = rospy.Time.now()
        dt = (current_time - self.prev_time).to_sec()
        self.prev_time = current_time

        # Calculate distance moved by each wheel
        delta_left = (self.encoder_left - self.prev_encoder_left) * (2 * math.pi * self.wheel_radius) / self.ticks_per_revolution
        delta_right = (self.encoder_right - self.prev_encoder_right) * (2 * math.pi * self.wheel_radius) / self.ticks_per_revolution
        self.prev_encoder_left = self.encoder_left
        self.prev_encoder_right = self.encoder_right

        # Calculate the average distance and change in angle
        delta_s = (delta_left + delta_right) / 2.0
        delta_theta = (delta_right - delta_left) / self.wheel_base

        # Update the pose
        self.x += delta_s * math.cos(self.th + delta_theta / 2.0)
        self.y += delta_s * math.sin(self.th + delta_theta / 2.0)
        self.th += delta_theta

        # Create quaternion from yaw
        odom_quat = tf.transformations.quaternion_from_euler(0, 0, self.th)

        # Create and publish the odometry message
        odom = Odometry()
        odom.header.stamp = current_time
        odom.header.frame_id = "odom"
        odom.child_frame_id = "base_link"
        odom.pose.pose.position.x = self.x
        odom.pose.pose.position.y = self.y
        odom.pose.pose.position.z = 0.0
        odom.pose.pose.orientation.x = odom_quat[0]
        odom.pose.pose.orientation.y = odom_quat[1]
        odom.pose.pose.orientation.z = odom_quat[2]
        odom.pose.pose.orientation.w = odom_quat[3]
        odom.twist.twist.linear.x = delta_s / dt
        odom.twist.twist.angular.z = delta_theta / dt

        self.odom_pub.publish(odom)

        # Broadcast the transform over tf
        self.odom_broadcaster.sendTransform(
            (self.x, self.y, 0),
            odom_quat,
            current_time,
            "base_link",
            "odom"
        )

    def spin(self):
        while not rospy.is_shutdown():
            self.compute_odometry()
            self.rate.sleep()

if __name__ == '__main__':
    try:
        odometry_publisher = OdometryPublisher()
        odometry_publisher.spin()
    except rospy.ROSInterruptException:
        pass
